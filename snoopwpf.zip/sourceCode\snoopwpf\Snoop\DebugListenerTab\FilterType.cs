﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Snoop.DebugListenerTab
{
	public enum FilterType
	{
		StartsWith,
		EndsWith,
		Contains,
		RegularExpression
	}
}
